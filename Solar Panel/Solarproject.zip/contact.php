<?php
if(isset($_POST["submit"])){
  $username = $_POST['name'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $message = $_POST['message'];

  $conn = new mysqli('localhost','root','','testt');
  if($conn->connect_error){
    die('Connection Failed : '.$conn->connect_error);
  }else{
     $stmt = $conn->prepare("insert into conactform(username, email, phone, message)values(?, ?, ?, ?)");
     $stmt->bind_param("ssis",$username,$email,$phone,$message);
     $stmt->execute();
     echo "submitted...";
     $stmt->close();
     $conn->close();
  }
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Contact Form</title>
    <link rel="stylesheet" href="style2.css" />
    <script
      src="https://kit.fontawesome.com/64d58efce2.js"
      crossorigin="anonymous"
    ></script>
  </head>
  <body>
    <div class="container">
      
      <div class="form">
        <div class="contact-info">
          <h3 class="title">Let's get in touch</h3>
          <p class="text">
            Send us your message and we'll get back to you within 2 -4  business hours.
            In case, you are looking for technical support while doing Installations, have issue with existing product, Call : 011-4003 6959.
          </p>

          <div class="info">
            <div class="information">
             
              <p>92 Cherry Drive Uniondale, NY 11553</p>
            </div>
            <div class="information">
              
              <p>solar@panel.com</p>
            </div>
            <div class="information">
              
              <p>123-456-7892</p>
            </div>
          </div>

          <div class="social-media">
            <p>Connect with us :</p>
            <div class="social-icons">
              <a href="https://www.facebook.com">
                <i class="fab fa-facebook-f"></i>
              </a>
              <a href="https://twitter.com">
                <i class="fab fa-twitter"></i>
              </a>
              <a href="https://www.instagram.com">
                <i class="fab fa-instagram"></i>
              </a>
              <a href="https://www.linkedin.com">
                <i class="fab fa-linkedin-in"></i>
              </a>
            </div><br>
            <!-- <div class="credit">Made with <span style="color:tomato">❤</span> by <a href="">Solar Team</a></div> -->
          </div>
        </div>

        <div class="contact-form">
          <span class="circle one"></span>
          <span class="circle two"></span>

          <form action="" method="post" autocomplete="off">
            <h3 class="title">Contact us</h3>
            <div class="input-container">
              <input type="text" name="name" class="input" />
              <label for="">Username</label>
              <span>Username</span>
            </div>
            <div class="input-container">
              <input type="email" name="email" class="input" />
              <label for="">Email</label>
              <span>Email</span>
            </div>
            <div class="input-container">
              <input type="tel" name="phone" class="input" />
              <label for="">Phone</label>
              <span>Phone</span>
            </div>
            <div class="input-container textarea">
              <textarea name="message" class="input"></textarea>
              <label for="">Message</label>
              <span>Message</span>
            </div>
            <input type="submit" name="submit" value="Send" class="btn" />
          </form>
        </div>
      </div>
    </div>
    <script src="script1.js"></script>
</body>
</html>