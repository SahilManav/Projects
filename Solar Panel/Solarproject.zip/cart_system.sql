-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 11, 2023 at 06:40 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cart_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_price` varchar(100) NOT NULL,
  `product_image` varchar(50) NOT NULL,
  `qty` int(10) NOT NULL,
  `total_price` varchar(100) NOT NULL,
  `product_code` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) NOT NULL,
  `name` varchar(40) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` int(50) NOT NULL,
  `address` varchar(30) NOT NULL,
  `pmode` varchar(30) NOT NULL,
  `products` varchar(50) NOT NULL,
  `amount_paid` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `name`, `email`, `phone`, `address`, `pmode`, `products`, `amount_paid`) VALUES
(10, 'tanishka garg', 'tanishkagarg011@gmail.com', 2147483647, 'hhh', 'cod', 'POLYCRYSTALLINE PANELS(1), POLYCRYSTALLINE PANELS(', '156000'),
(11, 'tanishka garg', 'tanishkagarg011@gmail.com', 2147483647, 'ghh', 'cod', '', '0'),
(12, 'tanishka garg', 'tanishkagarg011@gmail.com', 2147483647, 'fdsfsd', 'netbanking', '', '0'),
(13, 'tanishka garg', 'tanishkagarg011@gmail.com', 2147483647, 'dhfghnfnfg', 'netbanking', 'POLYCRYSTALLINE PANELS(2), POLYCRYSTALLINE PANELS(', '105000'),
(14, 'tanishka garg', 'tanishkagarg011@gmail.com', 2147483647, 'gfdfbdfh', 'cod', 'POLYCRYSTALLINE PANELS(3)', '90000'),
(15, 'tanishka garg', 'tanishkagarg011@gmail.com', 2147483647, 'asgchacbhsdvchsvc', 'cod', 'POLYCRYSTALLINE PANELS(4), POLYCRYSTALLINE PANELS(', '370000'),
(16, 'tanishka garg', 'tanishkagarg011@gmail.com', 2147483647, 'sdnabcan', 'netbanking', 'POLYCRYSTALLINE PANELS(0), POLYCRYSTALLINE PANELS(', '30000'),
(17, 'tanishka garg', 'tanishkagarg01@gmail.com', 2147483647, 'sfhsfhghfvdhv', 'cod', 'POLYCRYSTALLINE PANELS(8), POLYCRYSTALLINE PANELS(', '230000'),
(18, 'tanishka garg', 'tanishkagarg011@gmail.com', 2147483647, 'fghbfgn', 'cod', 'POLYCRYSTALLINE PANELS(5)', '125000'),
(19, 'drg', 'tanishkagarg011@gmail.com', 2147483647, 'fcf', 'cod', 'POLYCRYSTALLINE PANELS(1), POLYCRYSTALLINE PANELS(', '305000'),
(20, 'tanishka garg', 'riya8@gmail.com', 0, 'dvvsv', 'cod', 'POLYCRYSTALLINE PANELS(4)', '120000'),
(21, 'NAMAN GARG', 'namangarg820@gmail.com', 2147483647, 'A-16   KH-16 ADHYAPAK NAGAR ,N', 'cod', 'POLYCRYSTALLINE PANELS(4), POLYCRYSTALLINE PANELS(', '422000'),
(22, 'NAMAN GARG', 'namangarg820@gmail.com', 2147483647, 'A-16   KH-16 ADHYAPAK NAGAR ,N', 'cod', 'POLYCRYSTALLINE PANELS(1), POLYCRYSTALLINE PANELS(', '142000');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` varchar(50) NOT NULL,
  `product_qty` int(100) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `product_code` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `product_price`, `product_qty`, `product_image`, `product_code`) VALUES
(1, 'POLYCRYSTALLINE PANELS', '25000', 0, 'image/solar_panel.JPG', 'p1000'),
(2, 'POLYCRYSTALLINE PANELS', '30000', 0, 'image/solar_panel.JPG', 'p1793'),
(3, 'POLYCRYSTALLINE PANELS', '45000', 0, 'image/solar_panel.JPG', 'p6754'),
(4, 'POLYCRYSTALLINE PANELS', '56000', 0, 'image/solar_panel.JPG', 'p2345'),
(5, 'POLYCRYSTALLINE PANELS', '56000', 0, 'image/solar_panel.JPG', 'p7896');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
