 <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!--=============== FAVICON ===============-->
        <link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon">

        <!--=============== BOXICONS ===============-->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">

        <!--=============== SWIPER CSS ===============--> 
        <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">

        <!--=============== CSS ===============-->
        <link rel="stylesheet" href="assets/css/styles.css">

        <title>SOLAR PANEL WEBSITE</title>
    </head>
    <body>
        
        <!--==================== HEADER ====================-->
        <header class="header" id="header">
            <nav class="nav container">
                <img src="logo.png"class="nav__logo">
                </a>

                <div class="nav__menu" id="nav-menu">
                    <ul class="nav__list">
                        <li class="nav__item">
                            <a href="#home" class="nav__link active-link">Home</a>
                        </li>
                        <li class="nav__item">
                            <a href="#featured" class="nav__link">Featured</a>
                        </li>
                        <li class="nav__item">
                            <a href="index2.php" class="nav__link">Products</a>
                        </li>
                        <li class="nav__item">
                            <a href="#aboutus" class="nav__link">About Us</a>
                        </li>
                        <li class="nav__item">
                            <a href="contact.php" class="nav__link">Contact Us</a>
                        </li>
                    </ul>

                    <div class="nav__close" id="nav-close">
                        <i class='bx bx-x' ></i>
                    </div>
                </div>

                <div class="nav__btns">
                    <!-- Theme change button -->
                    <i class='bx bx-moon change-theme' id="theme-button"></i>

                    <!-- <div class="nav__shop" id="cart-shop">
                        <i class='bx bx-shopping-bag' ></i>
                    </div> -->

                    <div class="nav__toggle" id="nav-toggle">
                        <i class='bx bx-grid-alt' ></i>
                    </div>
                </div>
            </nav>
        </header>

        <!--==================== CART ====================-->
       

        <!--==================== MAIN ====================-->
        <main class="main">
            <!--==================== HOME ====================-->
            <section class="home" id="home">
                <div class="home__container container grid">
                    <div class="home__img-bg">
                        <img src="pic2.jpg" alt="" class="home__img">
                    </div>
    
                    <div class="home__social">
                        <a href="https://www.facebook.com/" target="_blank" class="home__social-link">
                            Facebook
                        </a>
                        <a href="https://twitter.com/" target="_blank" class="home__social-link">
                            Twitter
                        </a>
                        <a href="https://www.instagram.com/" target="_blank" class="home__social-link">
                            Instagram
                        </a>
                    </div>
    
                    <div class="home__data">
                        <h1 class="home__title"> <br>SOLAR PANEL</h1>
                        <p class="home__description">
                            If your area is troubled with frequent power cuts, it's time you invest in off-grid PWM Based solar system. It is a cost effective solution that lets you save extra solar energy in batteries to use during power cuts.
                        </p>
                        <span class="home__price"> Starting just at ₹15000</span>

                        <div class="home__btns">
                            <a href="#aboutus" class="button button--gray button--small">
                                Discover
                            </a>

                            
                        </div>
                    </div>
                </div>
            </section>
            <!--==================== TESTIMONIAL ====================-->
            <section class="testimonial section container" id="aboutus">
                <div class="testimonial__container grid">
                    <div class="swiper testimonial-swiper">
                        <div class="swiper-wrapper">
                            <div class="testimonial__card swiper-slide">
                                <div class="testimonial__quote">
                                    <i class='bx bxs-quote-alt-left' >ABOUT US</i>
                                </div>
                                <p class="testimonial__description">
                                    Go Solar, Go Green. Solar power is the best alternative to save on exorbitant bills. We, at Solar Delivery, provide solution to all your problems related to power consumption through solar power plant installation, repair and maintenance. 
                                </p>
                               
                            </div>

                            <div class="testimonial__card swiper-slide">
                                <div class="testimonial__quote">
                                    <i class='bx bxs-quote-alt-left' >ABOUT US</i>
                                </div>
                                <p class="testimonial__description">
                                    In the new millennium, it is imperative to be power-wise to make the environment sustainable as solar power plants are easy to install and maintain. And here we are to give you a greener, affordable and reliable alternative to your hefty electricity bills. 
                                </p>
                              
                            </div>

                            <div class="testimonial__card swiper-slide">
                                <div class="testimonial__quote">
                                    <i class='bx bxs-quote-alt-left' >ABOUT US</i>
                                </div>
                                <p class="testimonial__description">
                                    Our team has, in store, for you a variety of affordable and new designs of solar power panels to cater to all your needs. As the design of solar panels depends on variety of factors such as, inverter, ACDB, DCDB, earthing-kit, structure, etc. we prefer giving you the best of solutions in solar plant installation.
                                </p>
                               
                            </div>
                        </div>
                        
                        <div class="swiper-button-next">
                            <i class='bx bx-right-arrow-alt' ></i>
                        </div>
                        <div class="swiper-button-prev">
                            <i class='bx bx-left-arrow-alt' ></i>
                        </div>
                    </div>

                    <div class="testimonial__images">
                        <div class="testimonial__square"></div>
                        <img src="pic1.jpg" alt="" class="testimonial__img">
                    </div>
                </div>
            </section>            

            <!--==================== FEATURED ====================-->
            <section class="featured section container" id="featured">
                <h2 class="section__title">
                    Featured
                </h2>

                <div class="featured__container grid">
                    <article class="featured__card">
                        <span class="featured__tag">Sale</span>

                        <img src="https://navitassolar.in/wp-content/uploads/2021/09/Solar-Panels.jpg" alt="" class="featured__img">

                        <div class="featured__data">
                            <h3 class="featured__title">Mono PERC</h3>
                            <span class="featured__price">₹11450</span>
                        </div>
                       <a href ="index2.php">
                        <button class="button featured__button">DISCOVER</button>
                        </a>
                    </article>

                    <article class="featured__card">
                        <span class="featured__tag">Sale</span>

                        <img src="https://5.imimg.com/data5/UZ/ZM/FL/SELLER-81343669/panasonic-solar-panels-320-watt-500x500-500x500.jpg" alt="" class="featured__img">

                        <div class="featured__data">
                            <h3 class="featured__title">Navisol Series </h3>
                            <span class="featured__price">₹12455</span>
                        </div>
                        <a href ="index2.php">
                        <button class="button featured__button">DISCOVER</button>
                         </a>
                    </article>

                    <article class="featured__card">
                        <span class="featured__tag">Sale</span>

                        <img src="https://5.imimg.com/data5/EZ/UM/HD/SELLER-77157614/panasonic-monoperc-380wp-solar-panels-500x500.jpg" alt="" class="featured__img">

                        <div class="featured__data">
                            <h3 class="featured__title">Mono PERC Half Cut Cell</h3>
                            <span class="featured__price">₹19455</span>
                        </div>
                        <a href ="index2.php">
                        <button class="button featured__button">DISCOVER</button>
                        </a>
                    </article>
                </div>
            </section>

            <!--==================== STORY ====================-->
            <section class="story section container">
                <div class="story__container grid">
                    <div class="story__data">
                        <h2 class="section__title story__section-title">
                          Solar Panel 
                        </h2>
    
                        <h1 class="story__title">
                            How Does It  <br> Works?
                        </h1>
    
                        <p class="story__description">
                            Solar panels are made out of photovoltaic cells that convert the sun’s energy into electricity.

                        Photovoltaic cells are sandwiched between layers of semi-conducting materials such as silicon. Each layer has different electronic properties that energise when hit by photons from sunlight, creating an electric field. This is known as the photoelectric effect – and it’s this that creates the current needed to produce electricity.

                        Solar panels generate a direct current of electricity. This is then passed through an inverter to convert it into an alternating current, which can be fed into the National Grid or used by the home or business the solar panels are attached to.
                        </p>
                    </div>

                    <div class="story__images">
                        <img src="pic3.jpg" alt="" class="story__img">
                        <div class="story__square"></div>
                    </div>
                </div>
            </section>

            <!--==================== PRODUCTS ====================-->
            <!-- <section class="products section container" id="products">
                <h2 class="section__title">
                    Products
                </h2>

                <div class="products__container grid">
                    <article class="products__card">
                        <img src="https://5.imimg.com/data5/QB/CT/MY-956949/monocrystalline-solar-panel-250x250.jpg" alt="" class="products__img">

                        <h3 class="products__title">60 mono cells</h3>
                        <span class="products__price">₹1500</span>

                        <button class="products__button">
                            <i class='bx bx-shopping-bag'></i>
                        </button>
                    </article>

                    <article class="products__card">
                        <img src="https://image.made-in-china.com/202f0j00vkfYdSiRAboq/Max-Efficiency-9bb-120-Half-Cut-158-Solar-Cells-345W-Mono-Perc-Solar-Panel.jpg" alt="" class="products__img">

                        <h3 class="products__title">120-half cut mono cells</h3>
                        <span class="products__price">₹1350</span>

                        <button class="products__button">
                            <i class='bx bx-shopping-bag'></i>
                        </button>
                    </article>

                    <article class="products__card">
                        <img src="https://www.ecodirect.com/v/vspfiles/photos/BP-Solar-SX-485J-2.jpg?v-cache=1659436146" alt="" class="products__img">

                        <h3 class="products__title">60 or 90 IBC cells</h3>
                        <span class="products__price">₹1870</span>

                        <button class="products__button">
                            <i class='bx bx-shopping-bag'></i>
                        </button>
                    </article>

                    <article class="products__card">
                        <img src="https://www.solar-capital.com/uploads/202117376/small/full-black-330w-335w-340w-345w55090749297.jpg" alt="" class="products__img">

                        <h3 class="products__title">Singled-cells</h3>
                        <span class="products__price">₹1650</span>

                        <button class="products__button">
                            <i class='bx bx-shopping-bag'></i>
                        </button>
                    </article>

                    <article class="products__card">
                        <img src="https://5.imimg.com/data5/SELLER/Default/2021/5/GM/LU/QR/6326311/1000v-solar-panel-500x500.jpg" alt="" class="products__img">

                        <h3 class="products__title">60 multi bushbar cells</h3>
                        <span class="products__price">₹1950</span>

                        <button class="products__button">
                            <i class='bx bx-shopping-bag'></i>
                        </button>
                    </article>
                        <article class="products__card">
                            <img src="https://images-na.ssl-images-amazon.com/images/I/41quISxTxgL._SR600%2C315_PIWhiteStrip%2CBottomLeft%2C0%2C35_SCLZZZZZZZ_FMpng_BG255%2C255%2C255.jpg" alt="" class="products__img">
    
                            <h3 class="products__title">60 aluminium cells</h3>
                            <span class="products__price">₹1800</span>
    
                            <button class="products__button">
                                <i class='bx bx-shopping-bag'></i>
                            </button>
                        </article>
                </div>
            </section> -->
        <!--==================== FOOTER ====================-->
        <br><br><hr>
        <footer class="footer section">
            <div class="footer__container container grid">
                <div class="footer__content">
                    <h2 class="footer__title">Our information</h2>

                    <ul class="footer__list">
                        <li>1234 - Peru</li>
                        <li>La Libertad 43210</li>
                        <li>123-456-789</li>
                    </ul>
                </div>
                <div class="footer__content">
                    <h3 class="footer__title">About Us</h3>

                    <ul class="footer__links">
                        <li>
                            <a href="#" class="footer__link">Support Center</a>
                        </li>
                        <li>
                            <a href="#" class="footer__link">Customer Support</a>
                        </li>
                        <li>
                            <a href="#" class="footer__link">About Us</a>
                        </li>
                        <li>
                            <a href="#" class="footer__link">Copy Right</a>
                        </li>
                    </ul>
                </div>

                <div class="footer__content">
                    <h3 class="footer__title">Product</h3>

                    <ul class="footer__links">
                        <li>
                            <a href="#" class="footer__link">Road bikes</a>
                        </li>
                        <li>
                            <a href="#" class="footer__link">Mountain bikes</a>
                        </li>
                        <li>
                            <a href="#" class="footer__link">Electric</a>
                        </li>
                        <li>
                            <a href="#" class="footer__link">Accesories</a>
                        </li>
                    </ul>
                </div>

                <div class="footer__content">
                    <h3 class="footer__title">Social</h3>

                    <ul class="footer__social">
                        <a href="https://www.facebook.com/" target="_blank" class="footer__social-link">
                            <i class='bx bxl-facebook'></i>
                        </a>

                        <a href="https://twitter.com/" target="_blank" class="footer__social-link">
                            <i class='bx bxl-twitter' ></i>
                        </a>

                        <a href="https://www.instagram.com/" target="_blank" class="footer__social-link">
                            <i class='bx bxl-instagram' ></i>
                        </a>
                    </ul>
                </div>
            </div>

           
        </footer>

        <!--=============== SCROLL UP ===============-->
        <a href="#" class="scrollup" id="scroll-up"> 
            <i class='bx bx-up-arrow-alt scrollup__icon' ></i>
        </a>

        <!--=============== SWIPER JS ===============-->
        <script src="assets/js/swiper-bundle.min.js"></script>

        <!--=============== MAIN JS ===============-->
        <script src="assets/js/main.js"></script>
    </body>
</html>